import React from "react";
import "../../css/components/shared/Hero.scss";

function Hero() {
  return (
    <div id="hero">
      <h1 style={{ color: "#ffffff" }}>Discussion Leads To Solution</h1>
      {/* <form>
        <input type="text" placeholder="Search" />
        <button id="submitQuery">S</button>
      </form> */}
    </div>
  );
}

export default Hero;
